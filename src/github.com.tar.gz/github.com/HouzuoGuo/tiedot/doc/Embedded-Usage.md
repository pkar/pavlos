APIs for embedded usage are demonstrated in `example.go`, you may run the example by building tiedot and run:

    ./tiedot -mode=example